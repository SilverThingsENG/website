	function myFunction() {
	  document.getElementById("fact1").innerHTML = "Stromzy got 6 A* GCSE's. Stromzy has also given speeches at Oxford University.";
	}
	function myFunction2() {
	  document.getElementById("fact2").innerHTML = "Stromzy has many names - including his real name, Micheal Omari, Stromzy is also known as Big Mike, The Problem, Wicked Skengman";
	}
	function myFunction3() {
	  document.getElementById("fact3").innerHTML = "Stromzy rose to fame on Youtube, not just rapping but singing too!";
	}



	function myFunction4() {
	  document.getElementById("fact4").innerHTML = "Dave's real name is just Dave or David! That explains his stage name, Santan Dave or Dave Santan";
	}
	function myFunction5() {
	  document.getElementById("fact5").innerHTML = "Dave started studing Ethics at college in 2015";
	}
	function myFunction6() {
	  document.getElementById("fact6").innerHTML = "Dave has some famous fans including Stormzy and Wiley!";
	}
